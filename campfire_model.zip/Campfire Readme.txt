Campfire Model
---------------------------

Geometry - Polygons
Faces - 5424
Vertices - 5805
---------------------------

Files included = Autodesk FBX,  Maya 2016 - Binary .mb and OBJ 

Textures = JPG 2048x2048, Diffuse, Normal, Specular Maps and a Glow map (burning woods)

Total 13 JPG Images. 

Textured in Zbrush and Adobe Photoshop. 

Rendered with Mental Ray Maya 2016. 

No additional plugins  required. 


---------------------------
Can be used Commercially with Credits
www.animatedheaven.weebly.com


using UnityEngine;

public class Vulcao : MonoBehaviour
{
    public ParticleSystem fumo;
    public float tamanhoInicial = 1;
    public float tamanhoMaximo = 5;
    public float tempoMaximo = 10;
    public float crescimento;
    public float tamanhoAtual;
    public float tempoParaFugir = 5f; // Tempo para o jogador fugir antes de morrer
    bool AvisoMeio = false;

    bool AvisoFim = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        fumo = GetComponent<ParticleSystem>();
        crescimento = (tamanhoMaximo - tamanhoInicial) / tempoMaximo;

        var main = fumo.main;
        main.startSize = tamanhoInicial;
        tamanhoAtual = tamanhoInicial;
        main.startLifetime = tempoMaximo;
    }
    
    // Update is called once per frame
    void Update()
    {
        if (tamanhoAtual / tamanhoMaximo> 0.5f && AvisoMeio==false)
        {
            SistemaMensagens.instance.MostrarMensagem("O vulc�o est� prestes a entrar em erup��o!");
            AvisoMeio = true;
        }
        if (tamanhoAtual < tamanhoMaximo)
        {
            var main = fumo.main;
            tamanhoAtual += Time.deltaTime * crescimento;
            main.startSize = tamanhoAtual;
        }
        if (tamanhoAtual>=tamanhoMaximo && AvisoFim == false)
        {
            SistemaMensagens.instance.MostrarMensagem("O vulc�o vai explodir!");
            AvisoFim = true;
            Invoke(nameof(MataPlayer), tempoParaFugir);
        }
    }

    void MataPlayer()
    {
        SistemaMensagens.instance.MostrarMensagem("Game Over");
        GameObject.FindAnyObjectByType<MenuJogo>().Sair();

    }
}

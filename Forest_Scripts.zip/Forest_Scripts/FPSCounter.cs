using UnityEngine;

public class FPSCounter : MonoBehaviour
{
    public float updateInterval = 0.5f; // Time interval to update the FPS counter
    private double lastInterval;
    private int frames = 0;
    private float fps;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        lastInterval = Time.realtimeSinceStartup;
        frames = 0;
    }

    // Update is called once per frame
    void Update()
    {
        frames++;
        float timeNow = Time.realtimeSinceStartup;
        if (timeNow > lastInterval + updateInterval)
        {
            fps = (float)(frames / (timeNow - lastInterval));
            lastInterval = timeNow;
            frames = 0;
        }
    }
    private void OnGUI()
    {
        GUILayout.Label(fps.ToString("f2"));

    }
}

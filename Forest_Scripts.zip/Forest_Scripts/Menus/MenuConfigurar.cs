using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuConfigurar : MonoBehaviour
{
    public TMP_Dropdown ddQualidade;
    public TMP_Dropdown ddResolucao;
    public Toggle tgFullScreen;
    public Toggle tgVSync;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        //atualizar a UI com os dados guardados
        tgFullScreen.isOn = PlayerPrefs.GetInt("fullscreen", 1) == 1;
        tgVSync.isOn = PlayerPrefs.GetInt("vsync", 1) == 1;
        int indiceQualidade = PlayerPrefs.GetInt("qualidade", 1);
        ddQualidade.value = indiceQualidade;

        string resolucao = PlayerPrefs.GetString("resolucao","1920x1080");
        string[] partes = resolucao.Split('x'); //1366x768
        int largura = int.Parse(partes[0]);
        int altura = int.Parse(partes[1]);

        for (int i = 0; i < ddResolucao.options.Count; i++)
        {
            if (ddResolucao.options[i].text == resolucao)
            {
                ddResolucao.value = i;
                break;
            }
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void NovaResolucao(int indice)
    {
        string resolucao = ddResolucao.options[indice].text;
        string[] partes = resolucao.Split('x'); //1366x768
        int largura = int.Parse(partes[0]);
        int altura = int.Parse(partes[1]);

        Screen.SetResolution(largura, altura, tgFullScreen.isOn);

        //guardar
        PlayerPrefs.SetString("resolucao", resolucao);
        PlayerPrefs.Save();
    }

    public void NovaQualidade(int indice)
    {
        QualitySettings.SetQualityLevel(indice,true);

        //guardar
        PlayerPrefs.SetInt("qualidade", indice);
        PlayerPrefs.Save();
    }

    public void NovaFullScreen()
    {
        Screen.fullScreen = tgFullScreen.isOn;
        //guardar
        PlayerPrefs.SetInt("fullscreen", tgFullScreen.isOn ? 1 : 0);
        PlayerPrefs.Save();
    }

    public void NovaVSync()
    {
        QualitySettings.vSyncCount = tgVSync.isOn ? 1 : 0;
        //guardar
        PlayerPrefs.SetInt("vsync", tgVSync.isOn ? 1 : 0);
        PlayerPrefs.Save();
    }

    public void Voltar()
    {
        SceneManager.LoadScene("menuprincipal");
    }


    public static void CarregarConfiguracao()
    {
        bool fullscreen = PlayerPrefs.GetInt("fullscreen", 1) == 1;
        int vsync = PlayerPrefs.GetInt("vsync", 1);
        int indiceQualidade = PlayerPrefs.GetInt("qualidade", 1);
        string resolucao = PlayerPrefs.GetString("resolucao", "1920x1080");
        string[] partes = resolucao.Split('x'); //1366x768
        int largura = int.Parse(partes[0]);
        int altura = int.Parse(partes[1]);

        //aplicar
        Screen.SetResolution(largura, altura, fullscreen);
        QualitySettings.vSyncCount = vsync;
        QualitySettings.SetQualityLevel(indiceQualidade, true);

    }
}

using UnityEngine;
using UnityEngine.SceneManagement;
//Menu principal do jogo
public class MenuPrincipal : MonoBehaviour
{
    private void Start()
    {
        MenuConfigurar.CarregarConfiguracao();
    }
    //carrega o n�vel 1
    public void Jogar()
    {
        SceneManager.LoadScene(3);  //n�vel 1
    }
    //terminar o jogo
    public void Sair()
    {
        Application.Quit();
    }
    //mostrar a cena sobre
    public void Sobre()
    {
        SceneManager.LoadScene(2);  //about
    }
    //voltar ao menu principal
    public void Voltar()
    {
        SceneManager.LoadScene(0);  //menu principal
    }

    public void Continuar()
    {
        int indiceGuardado = PlayerPrefs.GetInt("nivel", -1);
        if (indiceGuardado == -1)
            Jogar();
        else
            SceneManager.LoadScene(indiceGuardado);  //n�vel guardado
    }
    public void Configurar()
    {
        SceneManager.LoadScene("configurar");
    }
}

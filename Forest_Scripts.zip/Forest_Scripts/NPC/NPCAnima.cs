using UnityEngine;
using UnityEngine.AI;
/// <summary>
/// Controla as anima��es do NPC
/// </summary>
public class NPCAnima : MonoBehaviour
{
    Animator animator;
    NavMeshAgent agente;
    Vida vida;
    NPC npc;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        animator = GetComponent<Animator>();
        agente = GetComponent<NavMeshAgent>();
        vida = GetComponent<Vida>();
        npc = GetComponent<NPC>();
    }

    // Update is called once per frame
    void Update()
    {
        animator.SetFloat("velocidade", agente.velocity.magnitude/npc.Velocidade);

        if (vida.Morreu())
        {
            animator.SetBool("morreu", true);
            Invoke(nameof(Destroi), 10);
        }

        if (npc.Atacou)
        {
            animator.SetTrigger("ataca");
            npc.Atacou = false;
        }
    }

    void Destroi()
    {
        Destroy(gameObject);
    }
}

using UnityEngine;

public class PlayerAnima : MonoBehaviour
{
    PlayerMove playerMove;
    Animator animator;
    Vida vida;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        animator = GetComponent<Animator>();
        playerMove = GetComponent<PlayerMove>();
        vida=GetComponent<Vida>();
    }

    // Update is called once per frame
    void Update()
    {
        //blendtree
        animator.SetFloat("velocidade", playerMove._inputAndar);
        //saltar
        if (playerMove.IsJumping)
        {
            animator.SetTrigger("salta");
        }
        animator.SetBool("rightwalk", false);
        animator.SetBool("leftwalk", false);
        //andar lateral
        if (playerMove._movimentoLateral<0)
        {
            animator.SetBool("leftwalk", true);
            animator.SetBool("rightwalk", false);
        }
        if (playerMove._movimentoLateral > 0)
        {
            animator.SetBool("rightwalk", true);
            animator.SetBool("leftwalk", false);
        }
        if (vida.Morreu())
        {
            animator.SetBool("morrer", true);
        }
    }
}

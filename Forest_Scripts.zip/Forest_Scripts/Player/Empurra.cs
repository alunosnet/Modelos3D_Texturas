using UnityEngine;

public class Empurra : MonoBehaviour
{
    public float ForcaEmpurrar = 5f; // For�a de empurrar o objeto
    public float DelayEmpurrar = 0.2f;
    public float currentDelay = 0;
    public Rigidbody outroRb;
    public Collider outroCollider;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (SistemaInput.instance.Empurrar && outroCollider!=null && outroRb!=null)
        {
            if (Time.time<currentDelay)
            {
                return;
            }
            if (Utils.isInFront(gameObject, outroCollider.gameObject))
            {
                EmpurraObjeto();
                currentDelay = Time.time + DelayEmpurrar;
            }
        }

        //avaliar a distancia do outro objeto
        if (outroRb != null)
        {
            float distancia = Vector3.Distance(outroRb.transform.position, transform.position);
            if (distancia > 2f)
            {
                outroRb = null;
                outroCollider = null;
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if ( other.CompareTag("Player") == true || other.transform.gameObject.isStatic)
        {
            return;
        }
        
        if (other.GetComponent<Rigidbody>()==null)
        {
            return;
        }
        outroRb = other.GetComponent<Rigidbody>();
        outroCollider = other;
        Debug.Log("Empurra: " + outroRb.name);
    }
    private void OnTriggerExit(Collider other)
    {
        //if (other.CompareTag("Player") == true || other.transform.gameObject.isStatic)
        //{
        //    return;
        //}
        //Debug.Log("Saiu do trigger: " + other.name);
        //outroRb = null;
        //outroCollider = null;
    }

    void EmpurraObjeto()
    {
        if (outroRb == null || outroCollider == null)
        {
            return;
        }
        Vector3 direcao = outroCollider.transform.position - transform.position;
        outroRb.AddForceAtPosition(direcao.normalized * ForcaEmpurrar,
            outroCollider.ClosestPoint(transform.position) ,
            ForceMode.Impulse);
    }

}

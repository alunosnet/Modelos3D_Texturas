using UnityEngine;

public class PlayerAtaca : MonoBehaviour
{
    public float IntervaloAtaque = 1; // Intervalo entre ataques
    public float IntervaloAtual = 0;
    public int ValorTiraVida = 10;
    Animator _animator;
    Vida vida;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _animator = GetComponent<Animator>();
        vida = GetComponent<Vida>();
    }

    // Update is called once per frame
    void Update()
    {
        if (vida.Morreu())
            return;
        if (SistemaInput.instance.Atacar)
        {
            Atacar();
        }
    }
    void Atacar()
    {
        if (Time.time < IntervaloAtual) return;

        _animator.SetTrigger("pontape");
        IntervaloAtual = Time.time + IntervaloAtaque;
    }
}

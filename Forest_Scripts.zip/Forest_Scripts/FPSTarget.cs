using UnityEngine;

public class FPSTarget : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.LeftShift))
        {
            if (Input.GetKey(KeyCode.F1))
                Application.targetFrameRate = 10;
            if (Input.GetKey(KeyCode.F2))
                Application.targetFrameRate = 20;
            if (Input.GetKey(KeyCode.F3))
                Application.targetFrameRate = 30;
            if (Input.GetKey(KeyCode.F4))
                Application.targetFrameRate = 60;
            if (Input.GetKey(KeyCode.F5))
                Application.targetFrameRate = 300;
            Debug.Log("FPS Target: " + Application.targetFrameRate);
        }
    }
}

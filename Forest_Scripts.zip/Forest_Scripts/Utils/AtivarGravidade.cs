using UnityEngine;
/// <summary>
/// Ativa a gravidade de um rigidbody
/// </summary>
public class AtivarGravidade : MonoBehaviour
{
    public Rigidbody _rigidbody;

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            _rigidbody.useGravity = true;
        }
    }
}

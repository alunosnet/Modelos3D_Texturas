using UnityEngine;
using TMPro;
/// <summary>
/// Sistema para mostrar mensagens ao jogador
/// </summary>
public class SistemaMensagens : MonoBehaviour
{
    public static SistemaMensagens instance;
    public TextMeshProUGUI textoMensagem;

    private void Awake()
    {
        if (instance != null)
        {
            Destroy(gameObject);
            return;
        }
        instance = this;
        textoMensagem = GetComponent<TextMeshProUGUI>();
        EsconderMensagem();
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    public void MostrarMensagem(string texto,float duracao=4)
    {
        textoMensagem.text = texto;
        textoMensagem.enabled = true;
        Invoke(nameof(EsconderMensagem), duracao);
    }
    void EsconderMensagem()
    {
        textoMensagem.text = "";
        textoMensagem.enabled = false;
    }
}

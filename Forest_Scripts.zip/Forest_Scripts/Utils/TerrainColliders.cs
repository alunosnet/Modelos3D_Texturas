using System.Linq;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(Terrain))]
public class TerrainColliders : MonoBehaviour
{
    public Terrain terrain;

    
     void Reset()
    {
        terrain=GetComponent<Terrain>();
    }

    

    [ContextMenu("Limpar NavMeshObstacles")]
    /// <summary>
    /// Remove todos os NavMeshObstacles do terreno
    /// </summary>
    private void LimparMeshObstacles()
    {
        NavMeshObstacle[] obstacles = GetComponentsInChildren<NavMeshObstacle>();
        for(int i =obstacles.Length - 1; i >= 0; i--)
        {
            DestroyImmediate(obstacles[i]);
        }
    }
    [ContextMenu("Criar NavMeshObstacles")]
    ///<summary>
    /// Criar os NavMeshObstacles do terreno para cada �rvore
    /// </summary>
    private void CriarMeshObstacles()
    {
        LimparMeshObstacles();

        //percorrer as �rvores do terreno
        for(int i =0; i<terrain.terrainData.treePrototypes.Length; i++)
        {
            TreePrototype tree = terrain.terrainData.treePrototypes[i];
            //percorrer as �rvores do prot�tipo
            TreeInstance[] trees = terrain.terrainData.treeInstances
                .Where( t => t.prototypeIndex == i).ToArray();

            for (int j = 0; j < trees.Length; j++)
            {
                //posi��o da �rvore
                trees[j].position = Vector3.Scale(trees[j].position, terrain.terrainData.size);
                trees[j].position += terrain.GetPosition();

                //criar um gameobject vazio com o nome da �rvore
                GameObject obj = new GameObject();
                obj.name = tree.prefab.name + j;

                //posi��o do navmeshobstacle
                obj.transform.position = trees[j].position;
                //filho do terreno
                obj.transform.parent = terrain.transform;

                //adicionar componente navmeshobstacle
                var obst = obj.AddComponent<NavMeshObstacle>();
                obst.carving = true;

            }

        }
    }
}

using UnityEngine;
using Unity.Cinemachine;

public class CameraMove : MonoBehaviour
{
    CinemachineCamera cinemachine;
    CinemachineRotationComposer composer;
    public float velocidade = 1;
    public float MaxY = 2;
    public float MinY = -1;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        //refer�ncias
        cinemachine = GameObject.FindFirstObjectByType<CinemachineCamera>();
        composer = cinemachine.transform.GetComponent<CinemachineRotationComposer>();
    }

    // Update is called once per frame
    void Update()
    {
        float movimentoRato = SistemaInput.instance.DeltaRatoY;
        composer.TargetOffset.y += movimentoRato * Time.deltaTime * velocidade;
        //limitar o movimento
        composer.TargetOffset.y = Mathf.Clamp(composer.TargetOffset.y, MinY, MaxY);
    }
}

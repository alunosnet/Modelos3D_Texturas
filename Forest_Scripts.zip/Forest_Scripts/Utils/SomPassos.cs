using UnityEngine;
using UnityEngine.Rendering;
using System;

//Sons para passos e saltar
public class SomPassos : MonoBehaviour
{
    public AudioClip[] passos;
    public int ProximoSomPassos = 0;

    public AudioClip[] saltos;
    public int ProximoSomSaltos = 0;

    AudioSource _audioSource;

    Vector3 _posicaoAnterior;
    public float movimentoAcumulado = 0;
    public float TamanhoPasso = 1;

    bool saltou = false;
    public bool SomComAnimacoes = false;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _audioSource = GetComponent<AudioSource>();
        if (_audioSource == null)
        {
            _audioSource = gameObject.AddComponent<AudioSource>();
        }
        ConfigurarSom();
        _posicaoAnterior = transform.position;
    }
    
    void ConfigurarSom()
    {
        _audioSource.loop = false;
        _audioSource.playOnAwake = false;
        _audioSource.spatialBlend = 1;
    }

    void EscolheProximoSomPassos()
    {
        ProximoSomPassos++;
        if (ProximoSomPassos >= passos.Length)
        {
            ProximoSomPassos = 0;
        }
    }

    public void TocarSomPassos()
    {
        if (passos.Length == 0)
        {
            return;
        }
        _audioSource.PlayOneShot(passos[ProximoSomPassos]);
        EscolheProximoSomPassos();
    }

    void EscolheProximoSomSaltos()
    {
        ProximoSomSaltos++;
        if (ProximoSomSaltos >= saltos.Length)
        {
            ProximoSomSaltos = 0;
        }
    }
    public void TocarSomSaltos()
    {
        if (saltos.Length == 0)
        {
            return;
        }
        _audioSource.PlayOneShot(saltos[ProximoSomSaltos]);
        EscolheProximoSomSaltos();
    }
   
    // Update is called once per frame
    void Update()
    {
        if (SomComAnimacoes == true) return;
        float distancia = Vector3.Distance(transform.position, _posicaoAnterior);
        distancia = (float)Math.Round(distancia, 2);
        movimentoAcumulado += distancia;
        _posicaoAnterior = transform.position;
        if (movimentoAcumulado > TamanhoPasso)
        {
            
            TocarSomPassos();
            movimentoAcumulado = 0;
            
        }
        if (saltou == false)
        {
            TocarSomSaltos();
            movimentoAcumulado = 0;
            saltou = true;
        }
        if ( saltou == true)
        {
            saltou = false;
        }
    }
}

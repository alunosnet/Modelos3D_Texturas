using UnityEngine;
using UnityEngine.SceneManagement;

public class MudarNivel : MonoBehaviour
{
    public int ProximoNivel = 3;

    private void OnTriggerEnter(Collider other)
    {
        //verificar se o script est� ativado
        if (other.tag=="Player" && this.enabled==true)
        {
            if (ProximoNivel == -1)
                SceneManager.LoadScene("menuprincipal");
            else
                SceneManager.LoadScene(ProximoNivel);
        }
    }
   
}

using UnityEngine;

public class AtivarObjeto : MonoBehaviour
{
    public GameObject _objeto;

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            _objeto.SetActive(true);
        }
    }
   
}

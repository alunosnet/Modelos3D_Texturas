using UnityEngine;
/// <summary>
/// Script para ativar outro script
/// </summary>
public class AtivarScript : MonoBehaviour
{
    public MonoBehaviour ScriptAtivar;

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag=="Player")
        {
            ScriptAtivar.enabled = true;
        }
    }
}

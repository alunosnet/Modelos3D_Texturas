using UnityEngine;
using UnityEngine.UI;

public class Item : MonoBehaviour
{
    public string nome;
    public Image imagem;
    public bool tem;
}

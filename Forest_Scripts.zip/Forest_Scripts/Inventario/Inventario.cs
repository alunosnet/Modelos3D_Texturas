using UnityEngine;
using UnityEngine.UI;

public class Inventario : MonoBehaviour
{
    public Item[] items;    //items que o player tem de apanhar
    /// <summary>
    /// Adiciona o item indicado
    /// </summary>
    /// <param name="nome"></param>
    public void AdicionarItem(string nome)
    {
        foreach(Item item in items)
        {
            if (item.nome == nome && item.tem == false)
            {
                item.GetComponent<Image>().enabled = true;
                item.tem = true;
                SistemaMensagens.instance.MostrarMensagem("Apanhaste " + nome);
                break;
            }
        }
    }
    /// <summary>
    /// Devolve verdadeiro se existe um item com o nome indicado
    /// </summary>
    /// <param name="nome"></param>
    /// <returns></returns>
    public bool TemItem(string nome)
    {
        foreach (Item item in items)
        {
            if (item.nome == nome && item.tem == true)
            {
                return true;
            }
        }
        return false;
    }
}

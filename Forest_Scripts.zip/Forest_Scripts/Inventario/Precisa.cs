using UnityEngine;

public class Precisa : MonoBehaviour
{

    public string[] ItemsNecessarios;
    public GameObject[] Ativar;
    public string sucesso= "Sucesso";

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Inventario inventario = other.GetComponent<Inventario>();
            foreach(string item in  ItemsNecessarios)
            {
                if (inventario.TemItem(item) == false)
                {
                    SistemaMensagens.instance.MostrarMensagem("Precisas de " + item);
                    return;
                }
            }
            SistemaMensagens.instance.MostrarMensagem(sucesso);
            foreach(GameObject obj in Ativar)
            {
                obj.SetActive(true);
            }
        }
    }

}

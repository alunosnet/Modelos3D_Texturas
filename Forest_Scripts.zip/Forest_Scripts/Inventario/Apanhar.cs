using UnityEngine;

public class Apanhar : MonoBehaviour
{
    public string nome;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Inventario inventario = other.GetComponent<Inventario>();
            if (inventario != null)
            {
                inventario.AdicionarItem(nome);
                Destroy(gameObject); // Destroi o objeto ap�s apanhar
            }
        }
    }
}

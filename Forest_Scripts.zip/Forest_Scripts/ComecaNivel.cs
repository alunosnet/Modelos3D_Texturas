using UnityEngine;

public class ComecaNivel : MonoBehaviour
{
    public string MensagemInicial;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        SistemaMensagens.instance.MostrarMensagem(MensagemInicial);
    }

    
}

using UnityEngine;

public class teste_nao_fazer : MonoBehaviour
{
    GameObject[] objetos;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        objetos = GameObject.FindObjectsByType<GameObject>(FindObjectsSortMode.None);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

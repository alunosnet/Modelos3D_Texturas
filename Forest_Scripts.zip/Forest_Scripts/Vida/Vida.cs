using UnityEngine;
using UnityEngine.SceneManagement;
/// <summary>
/// Vida da personagem (player ou npc)
/// </summary>
public class Vida : MonoBehaviour
{
    public int MaxVida = 100;
    public int VidaAtual;
    AudioSource _audioSource;
    public AudioClip SomPerderVida;
    public AudioClip SomMorrer;
    public AudioClip SomGanharVida;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        VidaAtual = MaxVida;
        _audioSource = GetComponent<AudioSource>();
        if (_audioSource==null)
            _audioSource = gameObject.AddComponent<AudioSource>();
        _audioSource.loop = false;  //n�o repete
        _audioSource.playOnAwake = false;   //n�o toca ao iniciar
        _audioSource.spatialBlend = 1;      //som 3d
    }
    //tirar vida
    public void PerdeVida(int valor)
    {
        VidaAtual -= valor;
        if (VidaAtual<0)
        {
            VidaAtual = 0;
        }
        if (VidaAtual == 0)
        {
            if (SomMorrer != null)
            {
                _audioSource.clip = SomMorrer;
                _audioSource.Play();
            }
        }
        else
        {
            if (SomPerderVida!=null)
            {
                _audioSource.PlayOneShot(SomPerderVida);
            }
        }
            
    }
    //ganhar vida
    public void GanhaVida(int valor)
    {
        VidaAtual += valor;
        if (VidaAtual > MaxVida)
        {
            VidaAtual = MaxVida;
        }
        if (SomGanharVida != null)
        {
            _audioSource.PlayOneShot(SomGanharVida);
        }
    }
    //Indica se o player morreu
    public bool Morreu()
    {
        if (VidaAtual == 0)
            return true;
        return false;
    }
    void RecarregarNivelAtual()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}

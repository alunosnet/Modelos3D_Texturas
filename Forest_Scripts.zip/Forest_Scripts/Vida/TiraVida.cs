using UnityEngine;
/// <summary>
/// Script para tirar vida a uma personagem
/// </summary>
public class TiraVida : MonoBehaviour
{
    public int ValorPerdeVida = 10;
    public float IntervaloPerdeVida = 1;
    float ProximoIntervalo = 0;
    public string IgnoraTags = "";    //tags a ignorar e assim n�o tirar vida
    //Colis�o foi iniciada
    private void OnCollisionEnter(Collision collision)
    {
        ProcessaColisao(collision.gameObject);
    }
    //Colis�o continua (objetos em contacto)
    private void OnCollisionStay(Collision collision)
    {
        ProcessaColisao(collision.gameObject);
    }
    //colis�o com um collider definido como trigger
    private void OnTriggerEnter(Collider other)
    {
        ProcessaColisao(other.gameObject);
    }
    //Colis�o continua (trigger)
    private void OnTriggerStay(Collider other)
    {
        ProcessaColisao(other.gameObject);
    }
    //Vai tratar do que acontece quando existe uma colis�o
    void ProcessaColisao(GameObject quemColidiu)
    {
        //verificar se j� passou o tempo do intervalo
        if (Time.time < ProximoIntervalo)
            return;
        //verificar se o objeto tem a tag a ignorar
        if (IgnoraTags.Contains(quemColidiu.tag))
            return;
        //referencia para o script vida do objeto que colidiu
        var vida = quemColidiu.GetComponent<Vida>();
        //testar se o objeto tem o script vida
        if (vida!=null)
        {
            Debug.Log("Colidiu com: " + quemColidiu.name);
            vida.PerdeVida(ValorPerdeVida);
            
            ProximoIntervalo = Time.time + IntervaloPerdeVida;
        }
    }
}

using UnityEngine;
using UnityEngine.UI;
/// <summary>
/// Atualiza a barra de vida de acordo com a vida atual do jogador
/// </summary>
public class Vida_UI : MonoBehaviour
{
    [SerializeField]
    Vida vidaPlayer;
    [SerializeField]
    Image barraVida;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        barraVida = GetComponent<Image>();
        vidaPlayer = GameObject.FindGameObjectWithTag("Player").GetComponent<Vida>();
    }
    //Atualizar a barra da vida de acordo com a vida atual e o m�ximo de vida
    void AtualizaBarraVida()
    {
        float percentagem = (float)vidaPlayer.VidaAtual / vidaPlayer.MaxVida;
        barraVida.fillAmount = percentagem;
    }

    // Update is called once per frame
    void Update()
    {
        AtualizaBarraVida();
    }
}

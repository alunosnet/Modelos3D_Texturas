using UnityEngine;
/// <summary>
/// Script para tirar vida a uma personagem
/// </summary>
public class GanhaVida : MonoBehaviour
{
    public int ValorGanhaVida = 10;
    public float IntervaloGanhaVida = 30;
    float ProximoIntervalo = 0;
    public int ContagemGanhaVida = 1;
    //Colis�o foi iniciada
    private void OnCollisionEnter(Collision collision)
    {
        ProcessaColisao(collision.gameObject);
    }
    //Colis�o continua (objetos em contacto)
    private void OnCollisionStay(Collision collision)
    {
        ProcessaColisao(collision.gameObject);
    }
    //colis�o com um collider definido como trigger
    private void OnTriggerEnter(Collider other)
    {
        ProcessaColisao(other.gameObject);
    }
    //Colis�o continua (trigger)
    private void OnTriggerStay(Collider other)
    {
        ProcessaColisao(other.gameObject);
    }
    //Vai tratar do que acontece quando existe uma colis�o
    void ProcessaColisao(GameObject quemColidiu)
    {
        //verificar se j� passou o tempo do intervalo
        if (Time.time < ProximoIntervalo)
            return;
        //referencia para o script vida do objeto que colidiu
        var vida = quemColidiu.GetComponent<Vida>();
        //testar se o objeto tem o script vida
        if (vida!=null)
        {
            vida.GanhaVida(ValorGanhaVida);
            
            ProximoIntervalo = Time.time + IntervaloGanhaVida;

            ContagemGanhaVida--;
            if (ContagemGanhaVida <= 0)
            {
                Destroy(this.gameObject);
            }
        }
    }
}

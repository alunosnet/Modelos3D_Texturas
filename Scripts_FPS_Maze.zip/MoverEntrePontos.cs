using UnityEngine;
/// <summary>
/// Faz o movimento entre pontos
/// </summary>
public class MoverEntrePontos : MonoBehaviour
{
    public Transform[] Pontos;
    [Header("Movimento do objeto")]
    public float Velocidade = 1;
    [Tooltip("-1 Nunca para; >0 indica o nr de movimentos")]
    public int NrMovimentos = -1;   //-1 movimento cont�nuo
    int PontoAtual = 0;
    [Tooltip("Se verdadeiro quando bater no player volta atr�s")]
    public bool DetetaPlayer = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (DetetaPlayer == false)
            return;
        if (other.tag=="Player")
        {
            //voltar atr�s
            PontoAtual--;
            if (PontoAtual<0)
                PontoAtual = Pontos.Length - 1;
        }
    }

    // Update is called once per frame
    void Update()
    {
        //verificar se est� parado
        if (NrMovimentos == 0)
            return;
        //mover o objeto
        transform.position = Vector3.Lerp(transform.position, 
                                Pontos[PontoAtual].position, 
                                Velocidade * Time.deltaTime);
        //verifica se chegou ao ponto
        if (Vector3.Distance(transform.position, Pontos[PontoAtual].position)<0.1f)
        {
            //atualizar o nr de movimentos
            if (NrMovimentos>0)
                NrMovimentos--;
            if (NrMovimentos == 0)
                return;
            //mudar para o pr�ximo ponto
            PontoAtual++;
            if ( PontoAtual>=Pontos.Length)
            {
                PontoAtual = 0;
            }
        }


    }
}

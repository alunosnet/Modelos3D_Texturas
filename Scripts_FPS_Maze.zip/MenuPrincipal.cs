using UnityEngine;
using UnityEngine.SceneManagement;
//Menu principal do jogo
public class MenuPrincipal : MonoBehaviour
{
    //carrega o n�vel 1
    public void Jogar()
    {
        SceneManager.LoadScene(2);  //n�vel 1
    }
    //terminar o jogo
    public void Sair()
    {
        Application.Quit();
    }
    //mostrar a cena sobre
    public void Sobre()
    {
        SceneManager.LoadScene(1);  //about
    }
    //voltar ao menu principal
    public void Voltar()
    {
        SceneManager.LoadScene(0);  //menu principal
    }
}

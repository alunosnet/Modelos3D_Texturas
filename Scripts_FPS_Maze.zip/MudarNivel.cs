using UnityEngine;
using UnityEngine.SceneManagement;

public class MudarNivel : MonoBehaviour
{
    public int ProximoNivel = 3;

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag=="Player")
        {
            SceneManager.LoadScene(ProximoNivel);
        }
    }
   
}
